// **********************************************************************
//
// Copyright (c) 2003-2009 ZeroC, Inc. All rights reserved.
//
// This copy of Ice is licensed to you under the terms described in the
// ICE_LICENSE file included in this distribution.
//
// **********************************************************************

public final class IAI extends Test.MA._IADisp
{
    public
    IAI()
    {
    }

    public Test.MA.IAPrx
    iaop(Test.MA.IAPrx p, Ice.Current current)
    {
        return p;
    }
}
