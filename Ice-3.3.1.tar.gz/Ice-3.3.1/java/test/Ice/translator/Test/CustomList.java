package Test;

public class CustomList extends java.util.ArrayList
{
}
